= jQuery PHP

    Library for work with jQuery framework from server-side.

== Requirements

    * PHP 5.2.0 or higher (with JSON extension)
    * jQuery 1.1.2 or higher

== Documentation

    Please see the jQuery PHP  documentation on site: http://jquery.hohli.com

== Author

    name: Anton Shevchuk
    homepage: http://anton.shevchuk.name