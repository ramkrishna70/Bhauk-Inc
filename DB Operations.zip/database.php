<?php

/************************************************************************************
	Author		:	ANJANI KUMAR PIRATLA											*
	File Name 	:	database.php													*
	Licence		:	Freeware 														*
																					*
************************************************************************************/

// database variables
// change variables accordingly to suit your database settings
$server	  	= "localhost";
$database 	= "printorder";
$user		= "";
$pass		= "";

// define variables
define("br","<br>");
?>