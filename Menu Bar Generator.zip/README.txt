MenuBar Generator

This class was created to be used in PHP-GTK 2 with PHP 5. To see an example of how it works, take a look at 'example.php'.

What is PHP-GTK 2?

PHP-GTK 2 is the language binding for PHP 5 and GTK+ 2.6.x. It works independent of an Apache enviroment.
More information about the project at http://gtk.php.net

Any questions or bugs about this class, mail me. I will reply a soon as possible

Diego Feitosa
diego@dnfeitosa.com
