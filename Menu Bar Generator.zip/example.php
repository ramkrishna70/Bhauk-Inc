<?php
require_once("MenuBar.inc");
//header("content-type: text/plain");
$menu = new MenuBar();
$menu->createFromFile("menudef.xml");

/*
$xmlStr = <<<XML
<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE menubar SYSTEM "menudef.dtd">

<menubar>
	<menu display="_File" id="file" icon="icon1.jpg" tearoff="false">
		<item display="_Open" icon="Gtk::STOCK_OPEN" id="open" />
		<item display="_Save" icon="Gtk::STOCK_SAVE" id="save" />
		<item display="_Close" icon="Gtk::STOCK_CLOSE" id="close" />

		<separator />

		<item display="_Quit" icon="Gtk::STOCK_QUIT" id="quit" />
	</menu>

	<menu display="_Edit" id="edit" tearoff="true">
		<item display="_Cut" icon="Gtk::STOCK_CUT" id="cut" />
		<item display="C_opy" icon="Gtk::STOCK_COPY" id="copy" />
		<item display="_Paste" icon="Gtk::STOCK_PASTE" id="paste" />

		<separator />
		<menu display="Submenu" id="submenu" icon="icon1.jpg" tearoff="true">
			<item display="SubmenuItem" id="submenuitem" icon="icon1.jpg" />
		</menu>

		<item display="_MyPersonaItem" icon="icon1.jpg" id="personal" />
	</menu>
</menubar>
XML;
	
$menu->createFromString($xmlStr);
 */

$window = new GtkWindow();
$window->add($menu);
$window->show_all();

$window->connect_simple('destroy', array('Gtk', "main_quit"));


$open = $menu->getWidget("open");
$open->connect_simple("activate", "onActivate", "open");

$save = $menu->getWidget("save");
$save->connect_simple("activate", "onActivate", "save");

$close = $menu->getWidget("close");
$close->connect_simple("activate", "onActivate", "close");

$quit = $menu->getWidget("quit");
$quit->connect_simple("activate", "exitApp");

$cut = $menu->getWidget("cut");
$cut->connect_simple("activate", "onActivate", "cut");

$copy = $menu->getWidget("copy");
$copy->connect_simple("activate", "onActivate", "copy");

$paste = $menu->getWidget("paste");
$paste->connect_simple("activate", "onActivate", "paste");

$personal = $menu->getWidget("personal");
$personal->connect_simple("activate", "onActivate", "personal");

$submenu = $menu->getWidget("submenuitem");
$submenu->connect_simple("activate", "onActivate", "submenuItem");

function onActivate($name) {
	echo "The widget \"$name\" was activated\n";
}

function exitApp() {
	echo "Closing application\n";
	Gtk::main_quit();
}


Gtk::main();

?>
