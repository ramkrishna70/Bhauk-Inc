<html>
<META http-equiv="Refresh" content='120'>
<body bgcolor='#002266'>
<?php
     require './chat.php';
     $_SESSION['chat']->roomsList(FALSE);
?>
</body>
</html>
