<html>
<META http-equiv="Refresh" content='8'>
<body bgcolor='#002266'>
<?php
     require './chat.php';
     $_SESSION['chat']->chatDisplay();
?>
</body>
</html>
