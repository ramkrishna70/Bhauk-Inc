<html>
<frameset rows='10%,90%' frameborder="yes" border=2 framespacing=1>
    <frame src='./showRooms.php' framespacing=2 border=2>
    <frameset cols='80%, *' frameborder="yes" border=2 framespacing=1>
        <frameset rows='90%, *' frameborder="yes" border=2 framespacing=1>
            <frame src='./chatDisplay.php' framespacing=2 border=2>
            <frame src='./chatMsg.php' framespacing=2 border=2>
        </frameset>
        <frame src='./showUsers.php' framespacing=2 border=2>
    </frameset>
</html>
