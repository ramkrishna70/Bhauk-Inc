<html>
<body bgcolor='#002266'>
<?php
     require './chat.php';
     $_SESSION['chat']->chatMsg();
?>
</body>
</html>
