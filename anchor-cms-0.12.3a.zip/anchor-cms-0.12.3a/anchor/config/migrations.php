<?php

return array(
    /*
     * Latest migration
     * overide for testing/development
     */
    'current' => MIGRATION_NUMBER
);
