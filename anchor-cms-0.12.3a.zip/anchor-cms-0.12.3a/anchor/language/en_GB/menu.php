<?php

return array(

    'menu'        => 'Menu',
    'edit_menu' => 'Edit menu'

);
