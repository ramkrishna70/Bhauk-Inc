		<small>
			You’re installing Anchor version <?php echo VERSION; ?>.
			<a href="//twitter.com/anchorcms" target="_blank">Need help?</a>
		</small>

		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="<?php echo asset('views/assets/js/chosen.jquery.min.js'); ?>"></script>
		<script src="<?php echo asset('views/assets/js/main.js'); ?>"></script>
	</body>
</html>