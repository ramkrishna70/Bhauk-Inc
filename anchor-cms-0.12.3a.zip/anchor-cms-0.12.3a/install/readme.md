## Installing Anchor CMS

[It's on our site!](http://anchorcms.com/docs/getting-started/installing).