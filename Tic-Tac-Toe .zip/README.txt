If you want the computer to start the game, please make following change in Const object(/libs/Position.js):
TURN : this.COM
